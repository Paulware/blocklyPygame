event = None
sprite = None
ch = None
wPressed = None
surface = None
aPressed = None
sPressed = None
dPressed = None
obstacle = None
rect = None
playerImage = None
image = None
drawList = None
obstacleList = None
hitList = None

# Describe this function...
def movePlayer(event, sprite):
  global ch, wPressed, surface, aPressed, sPressed, dPressed, obstacle, rect, playerImage, image, drawList, obstacleList, hitList
  if (event.type) == (pygame.KEYDOWN):
    ch = chr(event.key)
    if ch == 'w':
      wPressed = True
    elif ch == 'a':
      aPressed = True
    elif ch == 's':
      sPressed = True
    elif ch == 'd':
      dPressed = True
  elif (event.type) == (pygame.KEYUP):
    ch = chr(event.key)
    if ch == 'w':
      wPressed = False
    elif ch == 'a':
      aPressed = False
    elif ch == 's':
      sPressed = False
    elif ch == 'd':
      dPressed = False
  if wPressed:
    sprite.rect.y=((sprite.rect.y) - 10)
  if aPressed:
    sprite.rect.x=((sprite.rect.x) - 10)
  if sPressed:
    sprite.rect.y=((sprite.rect.y) + 10)
  if dPressed:
    sprite.rect.x=((sprite.rect.x) + 10)


import pygame
pygame.init()
def get_key():
   src  = r"`1234567890-=qwertyuiop[]\asdfghjkl;'zxcvbnm,./"
   dest = r'~!@#$%^&*()_+QWERTYUIOP{}|ASDFGHJKL:"ZXCVBNM<>?'
   while 1:
      try:
         event = pygame.event.poll()
         if event.type == pygame.KEYDOWN:
            _ch = chr(event.key)
            if ord(_ch) != 304:
               pressed = pygame.key.get_pressed()
               if pressed[pygame.K_RSHIFT] or pressed[pygame.K_LSHIFT] and _ch in src:
                  _ch = dest[src.index(_ch)]
               break
      except Exception as ex:
         pass
   return _ch
pygame.display.set_caption('Sprite Application')
surface = pygame.display.set_mode ((800,600), (pygame.RESIZABLE))
obstacle = pygame.sprite.Sprite()
obstacle.image=(pygame.Surface([((100,100))[0],((100,100))[1]]))
(obstacle.image).fill(pygame.Color('#33cc00'));
rect = pygame.Rect(((200,10)),(((300,110))[0]-((200,10))[0],((300,110))[1]-((200,10))[1]))
obstacle.rect=rect
playerImage = pygame.sprite.Sprite()
image = pygame.image.load ('cannon.jpg').convert()
playerImage.image=image
playerImage.rect=(image.get_rect())
drawList = pygame.sprite.Group()
obstacleList = pygame.sprite.Group()
drawList.add(playerImage)
drawList.add(obstacle)
obstacleList.add(obstacle)
while True:
  event = pygame.event.poll()
  if (event.type) == (pygame.QUIT):
    break
  elif (event.type) == (pygame.KEYDOWN):
    movePlayer(event, playerImage)
  drawList.draw(surface)
  pygame.display.update()
  hitList = pygame.sprite.spritecollide(playerImage,obstacleList,False)
  if len(hitList) > 0:
    print('We got a collision')
    break
